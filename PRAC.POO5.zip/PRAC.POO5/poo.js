class Cuenta{
    constructor(nombre,cuenta, saldo){
        this.nombre = nombre;
        this.cuenta = cuenta;
        this.saldo = saldo;
    }

    get Nombre(){
        return this.nombre = this.nombre;
    }
    set Nombre(nombre){
        return this.nombre = this.nombre;
    }

    get Cuenta(){
        return this.cuenta = this.cuenta;
    }
    set Cuenta(cuenta){
        return this.cuenta = this.cuenta;
    }

    get Saldo(){
        this.saldo = this.saldo;
    }
    set Saldo(saldo){
        this.saldo = this.saldo;
    }

    RetiroDeposito(cantidad){
        if(cantidad > this.saldo){
            return "la cantidad ingresada es mayor al abono"
        } else {
            return (this.saldo = this.saldo - cantidad);
        }
    }

    AbonoDeposito(){
        return this.saldo = this.saldo + cantidad
    }
}

const btnRetiro = document.getElementById("btnRetiro")
const cliente = new Cuenta("Leo","0000000-2",0)
const btnAbono = document.getElementById("btnAbono")


btnRetiro.addEventListener("click",()=>{
const cantidad = document.getElementById("cantidad").value
const response = document.getElementById("respuesta")

response.innerText = cliente.RetiroDeposito(cantidad)

})

btnAbono.addEventListener("click", ()=>{
const cantidad = parseFloat(document.getElementById("cantidad").value)
const response = document.getElementById("respuesta")

response.innerText = cliente.AbonoDeposito(cantidad)
})